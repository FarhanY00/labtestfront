
package com.api;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author USER
 */
public class ConMan {
    static Connection con;
    static String url;
    
    public static Connection getConnection(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            try{
                url="jdbc:mysql://localhost:3306/phone_caller";
                con=DriverManager.getConnection(url, "root","admin");
            }
            catch(SQLException e) {
                System.out.println("Error ok?");
                e.printStackTrace();
            }
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        return con;
    }
}

package com.api;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class DBApi {
    static Connection con;
    static ResultSet rs;
    
    public static JSONObject registerNewUser(String email, String password) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String sql = "select * from register where email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            rs = ps.executeQuery();
            //cara cek, lepas tu 
            while (rs.next()){
                ada=1;
            }
            if (ada == 1) {//user already exist
                jo.put("status", 1);//Kalau user exist = 1
            } else{// not exist, add user into table db
                sql = "insert into register (email, password) values (?,?)";
                PreparedStatement ps2 = con.prepareStatement(sql);
                ps2.setString(1, email);
                ps2.setString(2, password);
                System.out.println(ps2.toString());
                ps2.executeUpdate();
                jo.put("status", 0);
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
    }
    
    public static JSONObject userAuthentication(String email, String pass) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String sql = "select * from register where email=? and password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            //cara cek, lepas tu 
            while (rs.next()){
                ada=1;
            }
            if (ada == 1) {//user already exist
                jo.put("status", 1);//Kalau user exist = 1
            } else{// not exist, add user into table db
                jo.put("status", 0);//Wrong or X de user
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
    }
    
    public static JSONArray getContactDataByOwner(String email) {
        JSONArray ja = new JSONArray();
        int index = 0;
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String sql = "select * from contacts where owneremail=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);            
            rs = ps.executeQuery();
            //cara cek, lepas tu 
            while (rs.next()){
                ada=1;
                JSONObject jo = new JSONObject();
                jo.put("id",rs.getString("id"));
                jo.put("name",rs.getString("name"));
                jo.put("phone",rs.getString("phone"));
                jo.put("email",rs.getString("email"));
                jo.put("addedDate",rs.getString("addedDate"));
                ja.add(index++,jo);
            }
            if (ada == 1) {//user already exist
                JSONObject jo = new JSONObject();
                jo.put("status", 1);//Kalau user exist = 1
                ja.add(index++,jo);
            } else{// not exist, add user into table db
                JSONObject jo = new JSONObject();
                jo.put("status", 0);//Wrong or X de user
                ja.add(index++,jo);
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return ja;
    }
    
    public static JSONObject addContactData(String firstname, String lastname, String extension, String jobtitle,String id, String email) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String name = firstname +" "+ lastname;
            String sql = "insert into staffs(name,extension,jobtitle,id,email) values(?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, extension);
            ps.setString(3, jobtitle);
            ps.setString(4, id);
            ps.setString(5, email);
            
            ps.executeUpdate();
            jo.put("status",1);
            //cara cek, lepas tu 
                       
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
    }
    
    public static JSONObject getContactDataById(String id) {
        JSONObject jo = new JSONObject();
        int index = 0;
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String sql = "select * from contacts where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, id);            
            rs = ps.executeQuery();
            //cara cek, lepas tu 
            while (rs.next()){
                ada=1;

                jo.put("id",rs.getString("id"));
                jo.put("name",rs.getString("name"));
                jo.put("phone",rs.getString("phone"));
                jo.put("email",rs.getString("email"));
                jo.put("addedDate",rs.getString("addedDate"));
          
            }
            if (ada == 1) {//user already exist
                jo.put("status", 1);//Kalau user exist = 1
            } else{// not exist, add user into table db
  
                jo.put("status", 0);//Wrong or X de user
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
    }
    
    public static JSONObject updateContactById(String firstname, String phone, String email, String contactid) {
        JSONObject jo = new JSONObject();
        int ada = 0;
        try{
            con = ConMan.getConnection();
            String sql = "update contacts set name=?, phone=?, email=? where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
           
            ps.setString(1, firstname);
            ps.setString(2, phone);
            ps.setString(3, email);
            ps.setString(4, contactid);
            
            System.out.println(ps.toString());
            
            ps.executeUpdate();
            jo.put("status",1);
            //cara cek, lepas tu 
                       
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
    }
    
    public static JSONObject delContactDataById(String contactid){
        JSONObject jo = new JSONObject();
        
        try{
            con = ConMan.getConnection();
            String sql = "delete from contacts where id=?";
            PreparedStatement ps = con.prepareStatement(sql);
           
            ps.setString(1, contactid);
  
            ps.executeUpdate();
            jo.put("status",1);
            //cara cek, lepas tu 
                       
        } catch(SQLException e){
            e.printStackTrace();
        }
        return jo;
        
    }
}
